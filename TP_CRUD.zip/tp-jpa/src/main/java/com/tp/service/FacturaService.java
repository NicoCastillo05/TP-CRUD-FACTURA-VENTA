package com.tp.service;

import com.tp.dto.FacturaDetalleRequestDTO;
import com.tp.dto.FacturaReporteDTO;
import com.tp.dto.FacturaRequestDTO;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class FacturaService {

    @PersistenceContext
    private EntityManager em;

    // ---------- helpers ----------

    private com.tp.Usuario obtenerUsuarioAuditoria() {
        com.tp.Usuario u = em.find(com.tp.Usuario.class, 1L);
        if (u == null) {
            u = new com.tp.Usuario("admin", "admin", "Admin", "Sistema");
            em.persist(u);
            em.flush();
        }
        return u;
    }

    private com.tp.PuntoVenta buscarPuntoVenta(Long id) {
        com.tp.PuntoVenta pv = em.find(com.tp.PuntoVenta.class, id);
        if (pv == null) throw new IllegalArgumentException("No existe PuntoVenta con id " + id);
        return pv;
    }

    private com.tp.CondicionIva buscarCondicionIva(Long id) {
        com.tp.CondicionIva ci = em.find(com.tp.CondicionIva.class, id);
        if (ci == null) throw new IllegalArgumentException("No existe CondicionIva con id " + id);
        return ci;
    }

    private com.tp.TipoMoneda buscarTipoMoneda(Long id) {
        com.tp.TipoMoneda tm = em.find(com.tp.TipoMoneda.class, id);
        if (tm == null) throw new IllegalArgumentException("No existe TipoMoneda con id " + id);
        return tm;
    }

    private com.tp.Cliente buscarCliente(Long id) {
        if (id == null) return null;
        com.tp.Cliente c = em.find(com.tp.Cliente.class, id);
        if (c == null) throw new IllegalArgumentException("No existe Cliente con id " + id);
        return c;
    }

    private com.tp.ListaPrecioArticulo buscarListaPrecioArticulo(Long id) {
        com.tp.ListaPrecioArticulo lpa = em.find(com.tp.ListaPrecioArticulo.class, id);
        if (lpa == null) throw new IllegalArgumentException("No existe ListaPrecioArticulo con id " + id);
        return lpa;
    }

    private double calcularImportes(com.tp.FacturaVenta factura) {
        double total = 0;
        for (com.tp.FacturaVentaDetalle d : factura.getDetalles()) {
            double neto = d.getCantidad() * d.getPrecioUnitario() * (1 - d.getPorcentajeBonificacion() / 100.0);
            d.setImporteNeto(neto);
            double iva = neto * 0.21; // IVA 21% por defecto
            d.setImporteIva(iva);
            d.setImporteSubtotal(neto + iva);
            total += d.getImporteSubtotal();
        }
        factura.setImporteTotal(total);
        return total;
    }

    // ---------- read (paginated) ----------

    public Page<FacturaReporteDTO> buscarFacturasFiltradas(
            Date fechaDesde, Date fechaHasta, String estado, Double montoMinimo,
            int page, int size) {

        StringBuilder jpql = new StringBuilder(
                "SELECT new com.tp.dto.FacturaReporteDTO(" +
                        "  f.numero, " +
                        "  f.fechaEmision, " +
                        "  COALESCE(c.denominacion, 'Consumidor Final'), " +
                        "  ci.denominacion, " +
                        "  pv.descripcion, " +
                        "  f.importeTotal, " +
                        "  f.estado, " +
                        "  COUNT(d)" +
                        ") " +
                        "FROM FacturaVenta f " +
                        "LEFT JOIN f.cliente c " +
                        "JOIN f.condicionIva ci " +
                        "JOIN f.puntoVenta pv " +
                        "LEFT JOIN f.detalles d " +
                        "WHERE 1=1 "
        );

        Map<String, Object> params = new HashMap<>();

        if (fechaDesde != null) {
            jpql.append("AND f.fechaEmision >= :fechaDesde ");
            params.put("fechaDesde", fechaDesde);
        }
        if (fechaHasta != null) {
            jpql.append("AND f.fechaEmision <= :fechaHasta ");
            params.put("fechaHasta", fechaHasta);
        }
        if (estado != null && !estado.trim().isEmpty()) {
            jpql.append("AND f.estado = :estado ");
            params.put("estado", estado);
        }
        if (montoMinimo != null) {
            jpql.append("AND f.importeTotal >= :montoMinimo ");
            params.put("montoMinimo", montoMinimo);
        }

        jpql.append("GROUP BY f.id, f.numero, f.fechaEmision, " +
                "c.denominacion, ci.denominacion, pv.descripcion, f.importeTotal, f.estado " +
                "ORDER BY f.fechaEmision, f.numero");

        TypedQuery<FacturaReporteDTO> query = em.createQuery(jpql.toString(), FacturaReporteDTO.class);
        params.forEach(query::setParameter);

        // count total (separate simple count over facturas matching filters, approx)
        StringBuilder countJpql = new StringBuilder("SELECT COUNT(f) FROM FacturaVenta f WHERE 1=1 ");
        Map<String, Object> cparams = new HashMap<>();
        if (fechaDesde != null) { countJpql.append("AND f.fechaEmision >= :fechaDesde "); cparams.put("fechaDesde", fechaDesde); }
        if (fechaHasta != null) { countJpql.append("AND f.fechaEmision <= :fechaHasta "); cparams.put("fechaHasta", fechaHasta); }
        if (estado != null && !estado.trim().isEmpty()) { countJpql.append("AND f.estado = :estado "); cparams.put("estado", estado); }
        if (montoMinimo != null) { countJpql.append("AND f.importeTotal >= :montoMinimo "); cparams.put("montoMinimo", montoMinimo); }
        TypedQuery<Long> countQuery = em.createQuery(countJpql.toString(), Long.class);
        cparams.forEach(countQuery::setParameter);
        long total = countQuery.getSingleResult();

        query.setFirstResult(page * size);
        query.setMaxResults(size);
        List<FacturaReporteDTO> content = query.getResultList();

        return new PageImpl<>(content, PageRequest.of(page, size), total);
    }

    // ---------- create ----------

    @Transactional
    public com.tp.FacturaVenta crear(FacturaRequestDTO dto) {
        com.tp.PuntoVenta pv = buscarPuntoVenta(dto.getPuntoVentaId());
        com.tp.CondicionIva ci = buscarCondicionIva(dto.getCondicionIvaId());
        com.tp.TipoMoneda tm = buscarTipoMoneda(dto.getTipoMonedaId());
        com.tp.Cliente cli = buscarCliente(dto.getClienteId());

        com.tp.Usuario auditor = obtenerUsuarioAuditoria();

        com.tp.FacturaVenta factura = new com.tp.FacturaVenta(
                dto.getNumero() != null ? dto.getNumero() : null,
                dto.getFechaEmision() != null ? dto.getFechaEmision() : new Date(),
                pv, cli, ci, tm,
                dto.getImporteCobrado(), dto.getImporteSaldo(), 0,
                dto.getEstado() != null ? dto.getEstado() : "ACTIVA",
                auditor);

        if (dto.getDetalles() != null) {
            for (FacturaDetalleRequestDTO d : dto.getDetalles()) {
                com.tp.ListaPrecioArticulo lpa = buscarListaPrecioArticulo(d.getArticuloId());
                com.tp.FacturaVentaDetalle det = new com.tp.FacturaVentaDetalle(
                        lpa, d.getDescripcion(), d.getCantidad(), d.getPrecioUnitario(),
                        d.getPorcentajeBonificacion(), 0, 0, 0);
                factura.agregarDetalle(det);
            }
        }
        calcularImportes(factura);

        em.persist(factura);
        em.flush();
        return factura;
    }

    // ---------- update ----------

    @Transactional
    public com.tp.FacturaVenta actualizar(Long id, FacturaRequestDTO dto) {
        com.tp.FacturaVenta factura = em.find(com.tp.FacturaVenta.class, id);
        if (factura == null) throw new jakarta.persistence.EntityNotFoundException("No existe Factura con id " + id);

        if (dto.getPuntoVentaId() != null) factura.setPuntoVenta(buscarPuntoVenta(dto.getPuntoVentaId()));
        if (dto.getCondicionIvaId() != null) factura.setCondicionIva(buscarCondicionIva(dto.getCondicionIvaId()));
        if (dto.getTipoMonedaId() != null) factura.setTipoMoneda(buscarTipoMoneda(dto.getTipoMonedaId()));
        if (dto.getClienteId() != null) factura.setCliente(buscarCliente(dto.getClienteId()));
        if (dto.getFechaEmision() != null) factura.setFechaEmision(dto.getFechaEmision());
        if (dto.getEstado() != null) factura.setEstado(dto.getEstado());
        if (dto.getObservaciones() != null) factura.setObservaciones(dto.getObservaciones());
        factura.setImporteCobrado(dto.getImporteCobrado());
        factura.setImporteSaldo(dto.getImporteSaldo());

        // reemplazar detalles
        if (dto.getDetalles() != null) {
            List<com.tp.FacturaVentaDetalle> existentes = new ArrayList<>(factura.getDetalles());
            for (com.tp.FacturaVentaDetalle d : existentes) {
                em.remove(d);
            }
            factura.limpiarDetalles();
        }

        if (dto.getDetalles() != null) {
            for (FacturaDetalleRequestDTO d : dto.getDetalles()) {
                com.tp.ListaPrecioArticulo lpa = buscarListaPrecioArticulo(d.getArticuloId());
                com.tp.FacturaVentaDetalle det = new com.tp.FacturaVentaDetalle(
                        lpa, d.getDescripcion(), d.getCantidad(), d.getPrecioUnitario(),
                        d.getPorcentajeBonificacion(), 0, 0, 0);
                factura.agregarDetalle(det);
            }
        }
        calcularImportes(factura);

        em.merge(factura);
        em.flush();
        return factura;
    }

    // ---------- delete (logical annulment) ----------

    @Transactional
    public void eliminar(Long id) {
        com.tp.FacturaVenta factura = em.find(com.tp.FacturaVenta.class, id);
        if (factura == null) throw new jakarta.persistence.EntityNotFoundException("No existe Factura con id " + id);
        factura.setEstado("ANULADA");
        factura.setFechaAnulacion(new Date());
        em.merge(factura);
        em.flush();
    }

    // ---------- find by id ----------

    public com.tp.FacturaVenta buscarPorId(Long id) {
        com.tp.FacturaVenta f = em.find(com.tp.FacturaVenta.class, id);
        if (f == null) throw new jakarta.persistence.EntityNotFoundException("No existe Factura con id " + id);
        return f;
    }
}
