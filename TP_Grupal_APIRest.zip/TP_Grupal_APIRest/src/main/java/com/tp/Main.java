package com.tp;

/** Punto de entrada del proyecto integrado. El ejemplo JPA original se conserva en documentacion/. */
public class Main {
    public static void main(String[] args) {
        ApiRestApplication.main(args);
    }
}
