package com.tp.apirest.servicio;

import com.tp.apirest.dto.*;
import com.tp.apirest.excepcion.*;
import com.tp.apirest.modelo.*;
import com.tp.Usuario;
import com.tp.apirest.repositorio.PedidoRepositorio;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.util.*;

@Service
public class PedidoServicio {
    private final PedidoRepositorio pedidos;
    private final UsuarioServicio usuarios;
    private final ProductoServicio productos;

    public PedidoServicio(PedidoRepositorio pedidos, UsuarioServicio usuarios, ProductoServicio productos) {
        this.pedidos = pedidos;
        this.usuarios = usuarios;
        this.productos = productos;
    }

    @Transactional(readOnly = true)
    public List<PedidoSalida> listar() {
        return pedidos.findAllByEliminadoFalse().stream().map(this::salida).toList();
    }

    @Transactional(readOnly = true)
    public PedidoSalida buscar(Long id) { return salida(obtener(id)); }

    @Transactional
    public PedidoSalida crear(PedidoEntrada entrada) {
        Usuario usuario = usuarios.obtener(entrada.usuarioId());
        Pedido pedido = new Pedido();
        pedido.setFecha(entrada.fecha() != null ? entrada.fecha() : LocalDate.now());
        pedido.setFormaPago(entrada.formaPago());
        pedido.setEstado(Estado.PENDIENTE);
        pedido.setUsuario(usuario);

        Set<Long> ids = new HashSet<>();
        for (DetalleEntrada d : entrada.detalles()) {
            if (!ids.add(d.productoId()))
                throw new SolicitudInvalida("No repetir un producto dentro del mismo pedido");
            Producto p = productos.obtener(d.productoId());
            if (!Boolean.TRUE.equals(p.getDisponible()))
                throw new SolicitudInvalida("Producto no disponible: " + p.getNombre());
            if (p.getStock() < d.cantidad())
                throw new SolicitudInvalida("Stock insuficiente para: " + p.getNombre());
            pedido.addDetallePedido(d.cantidad(), p);
            p.setStock(p.getStock() - d.cantidad());
        }
        pedido.calcularTotal();
        return salida(pedidos.saveAndFlush(pedido));
    }

    @Transactional
    public PedidoSalida cambiarEstado(Long id, PedidoEstadoEntrada entrada) {
        Pedido pedido = obtener(id);
        Estado anterior = pedido.getEstado();
        Estado nuevo = entrada.estado();
        if (anterior == Estado.CANCELADO && nuevo != Estado.CANCELADO)
            throw new SolicitudInvalida("No se puede reabrir un pedido cancelado");
        if (anterior != Estado.CANCELADO && nuevo == Estado.CANCELADO)
            devolverStock(pedido);
        pedido.setEstado(nuevo);
        return salida(pedido);
    }

    @Transactional
    public void eliminar(Long id) {
        Pedido pedido = obtener(id);
        if (pedido.getEstado() != Estado.CANCELADO) devolverStock(pedido);
        pedido.setEliminado(true);
    }

    private Pedido obtener(Long id) {
        return pedidos.findByIdAndEliminadoFalse(id)
                .orElseThrow(() -> new RecursoNoEncontrado("Pedido no encontrado: " + id));
    }

    private void devolverStock(Pedido pedido) {
        for (DetallePedido detalle : pedido.getDetalles()) {
            Producto p = detalle.getProducto();
            p.setStock(p.getStock() + detalle.getCantidad());
        }
    }

    private PedidoSalida salida(Pedido pedido) {
        List<DetalleSalida> detalles = pedido.getDetalles().stream()
                .map(d -> new DetalleSalida(d.getId(), d.getProducto().getId(),
                        d.getProducto().getNombre(), d.getCantidad(),
                        d.getSubtotal() / d.getCantidad(), d.getSubtotal())).toList();
        Usuario u = pedido.getUsuario();
        return new PedidoSalida(pedido.getId(), pedido.getFecha(), pedido.getEstado(),
                pedido.getTotal(), pedido.getFormaPago(), u.getId(),
                u.getNombre() + " " + u.getApellido(), detalles, pedido.getCreatedAt());
    }
}
