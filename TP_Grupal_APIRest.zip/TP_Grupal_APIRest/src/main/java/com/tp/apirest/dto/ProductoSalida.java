package com.tp.apirest.dto;

import java.time.LocalDateTime;

public record ProductoSalida(Long id, String nombre, Double precio, String descripcion,
    int stock, String imagen, Boolean disponible, Long categoriaId,
    String categoriaNombre, LocalDateTime createdAt) {}
