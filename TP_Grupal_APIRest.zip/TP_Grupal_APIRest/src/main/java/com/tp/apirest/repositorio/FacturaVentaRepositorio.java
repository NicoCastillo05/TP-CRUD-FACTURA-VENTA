package com.tp.apirest.repositorio;

import com.tp.FacturaVenta;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FacturaVentaRepositorio extends JpaRepository<FacturaVenta, Long> {
}
