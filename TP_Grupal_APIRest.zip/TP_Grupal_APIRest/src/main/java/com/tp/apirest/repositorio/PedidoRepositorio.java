package com.tp.apirest.repositorio;

import com.tp.apirest.modelo.Pedido;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.EntityGraph;
import java.util.Optional;
import java.util.List;

public interface PedidoRepositorio extends JpaRepository<Pedido, Long> {
    @EntityGraph(attributePaths = {"usuario", "detalles", "detalles.producto"})
    Optional<Pedido> findByIdAndEliminadoFalse(Long id);
    @EntityGraph(attributePaths = {"usuario", "detalles", "detalles.producto"})
    List<Pedido> findAllByEliminadoFalse();
    boolean existsByUsuarioIdAndEliminadoFalse(Long id);
}
