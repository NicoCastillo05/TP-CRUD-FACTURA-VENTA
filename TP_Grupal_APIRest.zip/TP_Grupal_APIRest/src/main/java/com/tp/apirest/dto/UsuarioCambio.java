package com.tp.apirest.dto;

import com.tp.apirest.modelo.Rol;
import jakarta.validation.constraints.*;

public record UsuarioCambio(@NotBlank String nombre, @NotBlank String apellido,
    @Email @NotBlank String mail, String celular, @NotNull Rol rol) {}
