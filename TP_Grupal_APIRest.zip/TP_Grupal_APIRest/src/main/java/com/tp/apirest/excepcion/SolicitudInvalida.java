package com.tp.apirest.excepcion;

public class SolicitudInvalida extends RuntimeException {
    public SolicitudInvalida(String mensaje) { super(mensaje); }
}
