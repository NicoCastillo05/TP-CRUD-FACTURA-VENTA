package com.tp.apirest.modelo;

public enum Rol { ADMIN, USUARIO }
