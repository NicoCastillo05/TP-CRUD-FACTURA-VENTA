package com.tp.apirest.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public record FacturaDetalleRequestDTO(
    @NotNull Long listaPrecioArticuloId,
    @Positive double cantidad,
    @Positive double precioUnitario,
    String descripcion,
    @Positive double porcentajeBonificacion
) {}
