package com.tp.apirest.repositorio;

import com.tp.ListaPrecioArticulo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ListaPrecioArticuloRepositorio extends JpaRepository<ListaPrecioArticulo, Long> {
}
