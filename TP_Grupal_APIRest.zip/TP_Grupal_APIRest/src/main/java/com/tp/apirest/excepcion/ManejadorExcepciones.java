package com.tp.apirest.excepcion;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.ConstraintViolationException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

@RestControllerAdvice
public class ManejadorExcepciones {
    private ResponseEntity<ErrorApi> armar(HttpStatus estado, String mensaje,
                                           HttpServletRequest request, Map<String, String> detalles) {
        return ResponseEntity.status(estado).body(new ErrorApi(LocalDateTime.now(),
                estado.value(), estado.getReasonPhrase(), mensaje, request.getRequestURI(), detalles));
    }

    @ExceptionHandler(RecursoNoEncontrado.class)
    public ResponseEntity<ErrorApi> noEncontrado(RecursoNoEncontrado e, HttpServletRequest request) {
        return armar(HttpStatus.NOT_FOUND, e.getMessage(), request, Map.of());
    }

    @ExceptionHandler(SolicitudInvalida.class)
    public ResponseEntity<ErrorApi> invalida(SolicitudInvalida e, HttpServletRequest request) {
        return armar(HttpStatus.BAD_REQUEST, e.getMessage(), request, Map.of());
    }

    @ExceptionHandler(RecursoDuplicado.class)
    public ResponseEntity<ErrorApi> duplicado(RecursoDuplicado e, HttpServletRequest request) {
        return armar(HttpStatus.CONFLICT, e.getMessage(), request, Map.of());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorApi> validacion(MethodArgumentNotValidException e, HttpServletRequest request) {
        Map<String, String> errores = new LinkedHashMap<>();
        e.getBindingResult().getFieldErrors().forEach(f -> errores.put(f.getField(), f.getDefaultMessage()));
        return armar(HttpStatus.BAD_REQUEST, "Revisar los datos enviados", request, errores);
    }

    @ExceptionHandler({HttpMessageNotReadableException.class, ConstraintViolationException.class})
    public ResponseEntity<ErrorApi> malFormato(Exception e, HttpServletRequest request) {
        return armar(HttpStatus.BAD_REQUEST, "JSON o parámetros inválidos", request, Map.of());
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<ErrorApi> integridad(DataIntegrityViolationException e, HttpServletRequest request) {
        return armar(HttpStatus.CONFLICT, "Los datos incumplen una restricción de la base", request, Map.of());
    }
}
