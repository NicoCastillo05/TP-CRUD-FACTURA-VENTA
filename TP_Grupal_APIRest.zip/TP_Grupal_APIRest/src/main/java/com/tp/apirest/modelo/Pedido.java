package com.tp.apirest.modelo;

import jakarta.persistence.*;
import com.tp.Usuario;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "pedidos")
public class Pedido extends Base implements Calculable {
    private LocalDate fecha;
    @Enumerated(EnumType.STRING)
    private Estado estado;
    private Double total = 0.0;
    @Enumerated(EnumType.STRING)
    private FormaPago formaPago;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario_id", nullable = false)
    private Usuario usuario;

    @OneToMany(mappedBy = "pedido", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<DetallePedido> detalles = new ArrayList<>();

    public Pedido() {}
    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }
    public Estado getEstado() { return estado; }
    public void setEstado(Estado estado) { this.estado = estado; }
    public Double getTotal() { return total; }
    public void setTotal(Double total) { this.total = total; }
    public FormaPago getFormaPago() { return formaPago; }
    public void setFormaPago(FormaPago formaPago) { this.formaPago = formaPago; }
    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }
    public List<DetallePedido> getDetalles() { return detalles; }

    public void addDetallePedido(int cantidad, Producto producto) {
        if (cantidad <= 0) throw new IllegalArgumentException("La cantidad debe ser mayor a cero");
        if (producto == null || producto.getPrecio() == null)
            throw new IllegalArgumentException("El producto debe tener un precio");
        DetallePedido existente = findeDetallePedidoByProducto(producto);
        if (existente != null) {
            existente.setCantidad(existente.getCantidad() + cantidad);
            existente.setSubtotal(existente.getCantidad() * producto.getPrecio());
        } else {
            DetallePedido detalle = new DetallePedido();
            detalle.setPedido(this);
            detalle.setProducto(producto);
            detalle.setCantidad(cantidad);
            detalle.setSubtotal(cantidad * producto.getPrecio());
            detalles.add(detalle);
        }
        calcularTotal();
    }

    public DetallePedido findeDetallePedidoByProducto(Producto producto) {
        return detalles.stream()
                .filter(d -> mismoProducto(d.getProducto(), producto))
                .findFirst().orElse(null);
    }

    public void deleteDetallePedidoByProducto(Producto producto) {
        detalles.removeIf(d -> mismoProducto(d.getProducto(), producto));
        calcularTotal();
    }

    private boolean mismoProducto(Producto primero, Producto segundo) {
        if (primero == segundo) return true;
        if (primero == null || segundo == null || primero.getId() == null) return false;
        return primero.getId().equals(segundo.getId());
    }

    @Override
    public void calcularTotal() {
        total = detalles.stream().mapToDouble(DetallePedido::getSubtotal).sum();
    }
}
