package com.tp.apirest.dto;

import java.time.LocalDateTime;

public record CategoriaSalida(Long id, String nombre, String descripcion,
    LocalDateTime createdAt) {}
