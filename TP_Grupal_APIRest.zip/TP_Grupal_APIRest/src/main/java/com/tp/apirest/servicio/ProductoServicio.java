package com.tp.apirest.servicio;

import com.tp.apirest.dto.*;
import com.tp.apirest.excepcion.*;
import com.tp.apirest.modelo.Producto;
import com.tp.apirest.repositorio.ProductoRepositorio;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class ProductoServicio {
    private final ProductoRepositorio productos;
    private final CategoriaServicio categorias;

    public ProductoServicio(ProductoRepositorio productos, CategoriaServicio categorias) {
        this.productos = productos;
        this.categorias = categorias;
    }

    @Transactional(readOnly = true)
    public List<ProductoSalida> listar() {
        return productos.findAllByEliminadoFalse().stream().map(this::salida).toList();
    }

    @Transactional(readOnly = true)
    public ProductoSalida buscar(Long id) { return salida(obtener(id)); }

    @Transactional
    public ProductoSalida crear(ProductoEntrada entrada) {
        Producto p = new Producto();
        copiar(p, entrada);
        return salida(productos.save(p));
    }

    @Transactional
    public ProductoSalida actualizar(Long id, ProductoEntrada entrada) {
        Producto p = obtener(id);
        copiar(p, entrada);
        return salida(p);
    }

    @Transactional
    public ProductoSalida modificarParcial(Long id, ProductoParcial entrada) {
        Producto p = obtener(id);
        if (entrada.nombre() != null) p.setNombre(noVacio(entrada.nombre(), "nombre"));
        if (entrada.precio() != null) p.setPrecio(entrada.precio());
        if (entrada.descripcion() != null) p.setDescripcion(noVacio(entrada.descripcion(), "descripcion"));
        if (entrada.stock() != null) p.setStock(entrada.stock());
        if (entrada.imagen() != null) p.setImagen(entrada.imagen());
        if (entrada.disponible() != null) p.setDisponible(entrada.disponible());
        if (entrada.categoriaId() != null) p.setCategoria(categorias.obtener(entrada.categoriaId()));
        return salida(p);
    }

    @Transactional
    public void eliminar(Long id) { obtener(id).setEliminado(true); }

    public Producto obtener(Long id) {
        return productos.findByIdAndEliminadoFalse(id)
                .orElseThrow(() -> new RecursoNoEncontrado("Producto no encontrado: " + id));
    }

    private void copiar(Producto p, ProductoEntrada entrada) {
        p.setNombre(entrada.nombre().trim());
        p.setPrecio(entrada.precio());
        p.setDescripcion(entrada.descripcion().trim());
        p.setStock(entrada.stock());
        p.setImagen(entrada.imagen());
        p.setDisponible(entrada.disponible());
        p.setCategoria(categorias.obtener(entrada.categoriaId()));
    }

    private String noVacio(String valor, String campo) {
        if (valor.isBlank()) throw new SolicitudInvalida("El campo " + campo + " no puede estar vacío");
        return valor.trim();
    }

    private ProductoSalida salida(Producto p) {
        return new ProductoSalida(p.getId(), p.getNombre(), p.getPrecio(), p.getDescripcion(),
                p.getStock(), p.getImagen(), p.getDisponible(), p.getCategoria().getId(),
                p.getCategoria().getNombre(), p.getCreatedAt());
    }
}
