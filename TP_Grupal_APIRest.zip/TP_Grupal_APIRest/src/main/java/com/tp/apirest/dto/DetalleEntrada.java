package com.tp.apirest.dto;

import jakarta.validation.constraints.*;

public record DetalleEntrada(@NotNull Long productoId, @NotNull @Positive Integer cantidad) {}
