package com.tp.apirest.excepcion;

public class RecursoNoEncontrado extends RuntimeException {
    public RecursoNoEncontrado(String mensaje) { super(mensaje); }
}
