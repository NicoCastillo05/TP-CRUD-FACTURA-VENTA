package com.tp.apirest.dto;

import com.tp.apirest.modelo.Rol;
import java.time.LocalDateTime;

public record UsuarioSalida(Long id, String nombre, String apellido, String mail,
    String celular, Rol rol, LocalDateTime createdAt) {}
