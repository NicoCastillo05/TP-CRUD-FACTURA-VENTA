package com.tp.apirest.controlador;

import com.tp.apirest.dto.*;
import com.tp.apirest.servicio.ProductoServicio;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/productos")
public class ProductoControlador {
    private final ProductoServicio servicio;
    public ProductoControlador(ProductoServicio servicio) { this.servicio = servicio; }

    @GetMapping
    public List<ProductoSalida> listar() { return servicio.listar(); }

    @GetMapping("/{id}")
    public ProductoSalida buscar(@PathVariable Long id) { return servicio.buscar(id); }

    @PostMapping
    public ResponseEntity<ProductoSalida> crear(@Valid @RequestBody ProductoEntrada entrada) {
        ProductoSalida creado = servicio.crear(entrada);
        return ResponseEntity.created(URI.create("/api/productos/" + creado.id())).body(creado);
    }

    @PutMapping("/{id}")
    public ProductoSalida actualizar(@PathVariable Long id, @Valid @RequestBody ProductoEntrada entrada) {
        return servicio.actualizar(id, entrada);
    }

    @PatchMapping("/{id}")
    public ProductoSalida modificar(@PathVariable Long id, @Valid @RequestBody ProductoParcial entrada) {
        return servicio.modificarParcial(id, entrada);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        servicio.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
