package com.tp.apirest.dto;

import java.util.Date;

public record FacturaReporteDTO(
        Long numeroFactura,
        Date fechaEmision,
        String clienteDenominacion,
        String condicionIva,
        String puntoVentaDescripcion,
        double importeTotal,
        long cantidadItems) { }
