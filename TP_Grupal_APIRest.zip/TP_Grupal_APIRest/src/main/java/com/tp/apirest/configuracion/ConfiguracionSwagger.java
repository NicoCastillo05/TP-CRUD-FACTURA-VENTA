package com.tp.apirest.configuracion;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ConfiguracionSwagger {
    @Bean
    public OpenAPI documentacion() {
        return new OpenAPI().info(new Info()
                .title("API REST - Gestión de pedidos y productos")
                .description("Trabajo práctico de Programación III - Spring Boot y JPA")
                .version("1.0"));
    }
}
