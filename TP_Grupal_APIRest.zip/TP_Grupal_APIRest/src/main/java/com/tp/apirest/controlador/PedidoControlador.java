package com.tp.apirest.controlador;

import com.tp.apirest.dto.*;
import com.tp.apirest.servicio.PedidoServicio;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/pedidos")
public class PedidoControlador {
    private final PedidoServicio servicio;
    public PedidoControlador(PedidoServicio servicio) { this.servicio = servicio; }

    @GetMapping
    public List<PedidoSalida> listar() { return servicio.listar(); }

    @GetMapping("/{id}")
    public PedidoSalida buscar(@PathVariable Long id) { return servicio.buscar(id); }

    @PostMapping
    public ResponseEntity<PedidoSalida> crear(@Valid @RequestBody PedidoEntrada entrada) {
        PedidoSalida creado = servicio.crear(entrada);
        return ResponseEntity.created(URI.create("/api/pedidos/" + creado.id())).body(creado);
    }

    @PatchMapping("/{id}/estado")
    public PedidoSalida cambiarEstado(@PathVariable Long id, @Valid @RequestBody PedidoEstadoEntrada entrada) {
        return servicio.cambiarEstado(id, entrada);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        servicio.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
