package com.tp.apirest.repositorio;

import com.tp.TipoMoneda;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TipoMonedaRepositorio extends JpaRepository<TipoMoneda, Long> {
}
