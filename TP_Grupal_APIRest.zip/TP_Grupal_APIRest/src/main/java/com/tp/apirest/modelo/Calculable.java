package com.tp.apirest.modelo;

public interface Calculable {
    void calcularTotal();
}
