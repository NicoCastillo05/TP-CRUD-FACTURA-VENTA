package com.tp.apirest.dto;

import jakarta.validation.constraints.*;

public record ProductoEntrada(@NotBlank String nombre, @NotNull @DecimalMin("0.01") Double precio,
    @NotBlank String descripcion, @NotNull @Min(0) Integer stock,
    String imagen, @NotNull Boolean disponible, @NotNull Long categoriaId) {}
