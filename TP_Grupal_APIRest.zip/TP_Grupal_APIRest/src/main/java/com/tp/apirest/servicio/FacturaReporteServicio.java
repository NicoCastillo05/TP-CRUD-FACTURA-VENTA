package com.tp.apirest.servicio;

import com.tp.apirest.dto.FacturaReporteDTO;
import com.tp.apirest.excepcion.SolicitudInvalida;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class FacturaReporteServicio {
    private final EntityManager em;

    public FacturaReporteServicio(EntityManager em) {
        this.em = em;
    }

    // La proyeccion JPQL consulta las entidades existentes, sin convertirlas en DTO a mano.
    @Transactional(readOnly = true)
    public List<FacturaReporteDTO> buscar(Date fechaDesde, Date fechaHasta,
                                          String estado, Double montoMinimo) {
        if (fechaDesde != null && fechaHasta != null && fechaDesde.after(fechaHasta))
            throw new SolicitudInvalida("La fecha desde no puede superar la fecha hasta");
        if (montoMinimo != null && montoMinimo < 0)
            throw new SolicitudInvalida("El monto mínimo no puede ser negativo");

        StringBuilder jpql = new StringBuilder("""
                SELECT new com.tp.apirest.dto.FacturaReporteDTO(
                    f.numero, f.fechaEmision,
                    COALESCE(c.denominacion, 'Consumidor Final'),
                    COALESCE(ci.denominacion, 'Sin condición de IVA'),
                    COALESCE(pv.descripcion, 'Sin descripción'),
                    f.importeTotal, COUNT(d))
                FROM FacturaVenta f
                LEFT JOIN f.cliente c
                LEFT JOIN f.condicionIva ci
                JOIN f.puntoVenta pv
                LEFT JOIN f.detalles d
                WHERE 1 = 1
                """);
        Map<String,Object> parametros = new LinkedHashMap<>();
        if (fechaDesde != null) {
            jpql.append(" AND f.fechaEmision >= :fechaDesde");
            parametros.put("fechaDesde", fechaDesde);
        }
        if (fechaHasta != null) {
            jpql.append(" AND f.fechaEmision <= :fechaHasta");
            parametros.put("fechaHasta", fechaHasta);
        }
        if (estado != null && !estado.isBlank()) {
            jpql.append(" AND f.estado = :estado");
            parametros.put("estado", estado.trim());
        }
        if (montoMinimo != null) {
            jpql.append(" AND f.importeTotal >= :montoMinimo");
            parametros.put("montoMinimo", montoMinimo);
        }
        jpql.append("""
                GROUP BY f.id, f.numero, f.fechaEmision, c.denominacion,
                         ci.denominacion, pv.descripcion, f.importeTotal
                ORDER BY f.fechaEmision DESC
                """);
        TypedQuery<FacturaReporteDTO> consulta = em.createQuery(jpql.toString(), FacturaReporteDTO.class);
        parametros.forEach(consulta::setParameter);
        return consulta.getResultList();
    }
}
