package com.tp.apirest.dto;

public record CategoriaParcial(String nombre, String descripcion) {}
