package com.tp.apirest.servicio;

import com.tp.apirest.dto.*;
import com.tp.apirest.excepcion.*;
import com.tp.Usuario;
import com.tp.apirest.repositorio.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class UsuarioServicio {
    private final UsuarioRepositorio usuarios;
    private final PedidoRepositorio pedidos;
    private final PasswordEncoder codificador;

    public UsuarioServicio(UsuarioRepositorio usuarios, PedidoRepositorio pedidos,
                           PasswordEncoder codificador) {
        this.usuarios = usuarios;
        this.pedidos = pedidos;
        this.codificador = codificador;
    }

    @Transactional(readOnly = true)
    public List<UsuarioSalida> listar() {
        return usuarios.findAllByEliminadoFalse().stream().map(this::salida).toList();
    }

    @Transactional(readOnly = true)
    public UsuarioSalida buscar(Long id) {
        Usuario u = obtener(id);
        System.out.println("Usuario encontrado por id: " + u.getId() + " - " + u.getNombre()
                + " " + u.getApellido() + " - " + u.getMail());
        return salida(u);
    }

    @Transactional(readOnly = true)
    public UsuarioSalida buscarPorMail(String mail) {
        Usuario usuario = usuarios.findByMailIgnoreCaseAndEliminadoFalse(mail.trim())
                .orElseThrow(() -> new RecursoNoEncontrado("No existe un usuario con ese mail"));
        System.out.println("Usuario encontrado por mail: " + usuario.getId() + " - " + usuario.getNombre()
                + " " + usuario.getApellido() + " - " + usuario.getMail());
        return salida(usuario);
    }

    @Transactional
    public UsuarioSalida crear(UsuarioEntrada entrada) {
        String mail = normalizarMail(entrada.mail());
        comprobarMail(mail, null);
        Usuario u = new Usuario();
        u.setNombre(entrada.nombre().trim());
        u.setApellido(entrada.apellido().trim());
        u.setUsuario(mail); // El TP anterior exige el nombre de usuario
        u.setMail(mail);
        u.setCelular(entrada.celular());
        u.setContrasena(codificador.encode(entrada.contrasena()));
        u.setRol(entrada.rol());
        return salida(usuarios.save(u));
    }

    @Transactional
    public UsuarioSalida actualizar(Long id, UsuarioCambio entrada) {
        Usuario u = obtener(id);
        String mail = normalizarMail(entrada.mail());
        comprobarMail(mail, id);
        u.setNombre(entrada.nombre().trim());
        u.setApellido(entrada.apellido().trim());
        u.setMail(mail);
        u.setCelular(entrada.celular());
        u.setRol(entrada.rol());
        return salida(u);
    }

    @Transactional
    public UsuarioSalida modificarParcial(Long id, UsuarioParcial entrada) {
        Usuario u = obtener(id);
        if (entrada.nombre() != null) u.setNombre(noVacio(entrada.nombre(), "nombre"));
        if (entrada.apellido() != null) u.setApellido(noVacio(entrada.apellido(), "apellido"));
        if (entrada.mail() != null) {
            String mail = normalizarMail(entrada.mail());
            comprobarMail(mail, id);
            u.setMail(mail);
        }
        if (entrada.celular() != null) u.setCelular(entrada.celular());
        if (entrada.contrasena() != null) u.setContrasena(codificador.encode(entrada.contrasena()));
        if (entrada.rol() != null) u.setRol(entrada.rol());
        return salida(u);
    }

    @Transactional
    public void eliminar(Long id) {
        Usuario u = obtener(id);
        if (pedidos.existsByUsuarioIdAndEliminadoFalse(id))
            throw new RecursoDuplicado("El usuario tiene pedidos activos; no se puede eliminar");
        u.setEliminado(true);
    }

    public Usuario obtener(Long id) {
        return usuarios.findByIdAndEliminadoFalse(id)
                .orElseThrow(() -> new RecursoNoEncontrado("Usuario no encontrado: " + id));
    }

    private String normalizarMail(String valor) {
        if (valor == null || valor.isBlank()) throw new SolicitudInvalida("El mail es obligatorio");
        return valor.trim().toLowerCase(java.util.Locale.ROOT);
    }

    private String noVacio(String valor, String campo) {
        if (valor.isBlank()) throw new SolicitudInvalida("El campo " + campo + " no puede estar vacío");
        return valor.trim();
    }

    private void comprobarMail(String mail, Long idActual) {
        usuarios.findByMailIgnoreCaseAndEliminadoFalse(mail).ifPresent(u -> {
            if (!u.getId().equals(idActual))
                throw new RecursoDuplicado("Ya existe un usuario con ese mail");
        });
        // La columna mail es única incluso si se eliminó lógicamente un usuario.
        usuarios.findByMailIgnoreCase(mail).ifPresent(u -> {
            if (!u.getId().equals(idActual))
                throw new RecursoDuplicado("Ese mail ya fue registrado anteriormente");
        });
    }

    private UsuarioSalida salida(Usuario u) {
        return new UsuarioSalida(u.getId(), u.getNombre(), u.getApellido(),
                u.getMail(), u.getCelular(), u.getRol(), u.getCreatedAt());
    }
}
