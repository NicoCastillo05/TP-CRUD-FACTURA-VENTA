package com.tp.apirest.modelo;

import jakarta.persistence.*;

@Entity
@Table(name = "categorias")
public class Categoria extends Base {
    private String nombre;

    private String descripcion;

    @OneToMany(mappedBy = "categoria")
    private java.util.List<Producto> productos = new java.util.ArrayList<>();

    public Categoria() {}

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public java.util.List<Producto> getProductos() { return productos; }
}
