package com.tp.apirest.excepcion;

public class RecursoDuplicado extends RuntimeException {
    public RecursoDuplicado(String mensaje) { super(mensaje); }
}
