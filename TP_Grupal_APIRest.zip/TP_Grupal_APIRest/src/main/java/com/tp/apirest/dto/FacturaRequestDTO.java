package com.tp.apirest.dto;

import java.util.Date;
import java.util.List;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record FacturaRequestDTO(
    @NotNull Long clienteId,
    @NotNull Long condicionIvaId,
    @NotNull Long puntoVentaId,
    @NotNull Long tipoMonedaId,
    @NotNull Date fechaEmision,
    Long numero,
    String estado,
    String observaciones,
    @NotNull @Size(min = 1) List<FacturaDetalleRequestDTO> detalles
) {}
