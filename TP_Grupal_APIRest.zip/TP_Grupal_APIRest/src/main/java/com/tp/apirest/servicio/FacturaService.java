package com.tp.apirest.servicio;

import com.tp.apirest.dto.*;
import com.tp.apirest.excepcion.*;
import com.tp.apirest.repositorio.*;
import com.tp.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class FacturaService {

    private final FacturaVentaRepositorio facturaVentaRepositorio;
    private final PuntoVentaRepositorio puntoVentaRepositorio;
    private final CondicionIvaRepositorio condicionIvaRepositorio;
    private final TipoMonedaRepositorio tipoMonedaRepositorio;
    private final ClienteRepositorio clienteRepositorio;
    private final ListaPrecioArticuloRepositorio listaPrecioArticuloRepositorio;
    private final UsuarioRepositorio usuarioRepositorio;

    public FacturaService(FacturaVentaRepositorio facturaVentaRepositorio,
                          PuntoVentaRepositorio puntoVentaRepositorio,
                          CondicionIvaRepositorio condicionIvaRepositorio,
                          TipoMonedaRepositorio tipoMonedaRepositorio,
                          ClienteRepositorio clienteRepositorio,
                          ListaPrecioArticuloRepositorio listaPrecioArticuloRepositorio,
                          UsuarioRepositorio usuarioRepositorio) {
        this.facturaVentaRepositorio = facturaVentaRepositorio;
        this.puntoVentaRepositorio = puntoVentaRepositorio;
        this.condicionIvaRepositorio = condicionIvaRepositorio;
        this.tipoMonedaRepositorio = tipoMonedaRepositorio;
        this.clienteRepositorio = clienteRepositorio;
        this.listaPrecioArticuloRepositorio = listaPrecioArticuloRepositorio;
        this.usuarioRepositorio = usuarioRepositorio;
    }

    @Transactional
    public FacturaReporteDTO crear(FacturaRequestDTO dto) {
        if (dto.detalles() == null || dto.detalles().isEmpty()) {
            throw new SolicitudInvalida("La factura debe tener al menos un detalle");
        }

        PuntoVenta puntoVenta = obtenerPuntoVenta(dto.puntoVentaId());
        CondicionIva condicionIva = obtenerCondicionIva(dto.condicionIvaId());
        TipoMoneda tipoMoneda = obtenerTipoMoneda(dto.tipoMonedaId());
        Cliente cliente = obtenerCliente(dto.clienteId());
        Usuario usuarioAuditoria = obtenerUsuarioAuditoria();

        List<FacturaVentaDetalle> detalles = new ArrayList<>();
        double importeTotal = 0.0;

        for (FacturaDetalleRequestDTO detalleDto : dto.detalles()) {
            ListaPrecioArticulo listaPrecioArticulo = obtenerListaPrecioArticulo(detalleDto.listaPrecioArticuloId());

            double importeNeto = detalleDto.cantidad() * detalleDto.precioUnitario()
                    * (1 - detalleDto.porcentajeBonificacion() / 100.0);
            double importeIva = importeNeto * 0.21;
            double importeSubtotal = importeNeto + importeIva;

            FacturaVentaDetalle detalle = new FacturaVentaDetalle(
                    listaPrecioArticulo,
                    detalleDto.descripcion(),
                    detalleDto.cantidad(),
                    detalleDto.precioUnitario(),
                    detalleDto.porcentajeBonificacion(),
                    importeNeto,
                    importeIva,
                    importeSubtotal
            );

            detalles.add(detalle);
            importeTotal += importeSubtotal;
        }

        FacturaVenta factura = new FacturaVenta(
                dto.numero(),
                dto.fechaEmision(),
                puntoVenta,
                importeTotal,
                0.0,
                importeTotal,
                "EMITIDA",
                usuarioAuditoria
        );
        factura.setCliente(cliente);
        factura.setCondicionIva(condicionIva);

        for (FacturaVentaDetalle detalle : detalles) {
            factura.agregarDetalle(detalle);
        }

        FacturaVenta guardada = facturaVentaRepositorio.save(factura);
        return mapearReporte(guardada);
    }

    @Transactional
    public FacturaReporteDTO actualizar(Long id, FacturaRequestDTO dto) {
        FacturaVenta factura = obtenerFactura(id);

        factura.setFechaEmision(dto.fechaEmision());
        factura.setEstado(dto.estado());
        factura.setObservaciones(dto.observaciones());
        factura.setPuntoVenta(obtenerPuntoVenta(dto.puntoVentaId()));
        factura.setCondicionIva(obtenerCondicionIva(dto.condicionIvaId()));
        obtenerTipoMoneda(dto.tipoMonedaId());
        factura.setCliente(obtenerCliente(dto.clienteId()));

        factura.setDetalles(new ArrayList<>());
        double importeTotal = 0.0;
        for (FacturaDetalleRequestDTO detalleDto : dto.detalles()) {
            ListaPrecioArticulo listaPrecioArticulo = obtenerListaPrecioArticulo(detalleDto.listaPrecioArticuloId());

            double importeNeto = detalleDto.cantidad() * detalleDto.precioUnitario()
                    * (1 - detalleDto.porcentajeBonificacion() / 100.0);
            double importeIva = importeNeto * 0.21;
            double importeSubtotal = importeNeto + importeIva;

            FacturaVentaDetalle detalle = new FacturaVentaDetalle(
                    listaPrecioArticulo,
                    detalleDto.descripcion(),
                    detalleDto.cantidad(),
                    detalleDto.precioUnitario(),
                    detalleDto.porcentajeBonificacion(),
                    importeNeto,
                    importeIva,
                    importeSubtotal
            );

            factura.agregarDetalle(detalle);
            importeTotal += importeSubtotal;
        }

        factura.setImporteTotal(importeTotal);
        factura.setImporteCobrado(importeTotal);

        FacturaVenta guardada = facturaVentaRepositorio.save(factura);
        return mapearReporte(guardada);
    }

    @Transactional
    public void eliminar(Long id) {
        FacturaVenta factura = obtenerFactura(id);
        factura.setEstado("ANULADA");
        factura.setFechaAnulacion(new Date());
        facturaVentaRepositorio.save(factura);
    }

    public FacturaVenta obtenerFactura(Long id) {
        return facturaVentaRepositorio.findById(id)
                .orElseThrow(() -> new RecursoNoEncontrado("Factura no encontrada: " + id));
    }

    private PuntoVenta obtenerPuntoVenta(Long id) {
        return puntoVentaRepositorio.findById(id)
                .orElseThrow(() -> new RecursoNoEncontrado("Punto de venta no encontrado: " + id));
    }

    private CondicionIva obtenerCondicionIva(Long id) {
        return condicionIvaRepositorio.findById(id)
                .orElseThrow(() -> new RecursoNoEncontrado("Condici\u00f3n de IVA no encontrada: " + id));
    }

    private TipoMoneda obtenerTipoMoneda(Long id) {
        return tipoMonedaRepositorio.findById(id)
                .orElseThrow(() -> new RecursoNoEncontrado("Tipo de moneda no encontrado: " + id));
    }

    private Cliente obtenerCliente(Long id) {
        return clienteRepositorio.findById(id)
                .orElseThrow(() -> new RecursoNoEncontrado("Cliente no encontrado: " + id));
    }

    private ListaPrecioArticulo obtenerListaPrecioArticulo(Long id) {
        return listaPrecioArticuloRepositorio.findById(id)
                .orElseThrow(() -> new RecursoNoEncontrado("Lista de precio art\u00edculo no encontrada: " + id));
    }

    private Usuario obtenerUsuarioAuditoria() {
        return usuarioRepositorio.findById(1L)
                .orElseThrow(() -> new RecursoNoEncontrado("Usuario de auditor\u00eda no encontrado (ID 1)"));
    }

    private FacturaReporteDTO mapearReporte(FacturaVenta factura) {
        return new FacturaReporteDTO(
                factura.getNumero(),
                factura.getFechaEmision(),
                factura.getCliente() != null ? factura.getCliente().getDenominacion() : "Consumidor Final",
                factura.getCondicionIva() != null ? factura.getCondicionIva().getDenominacion() : "Sin condici\u00f3n de IVA",
                factura.getPuntoVenta() != null ? factura.getPuntoVenta().getDescripcion() : "Sin descripci\u00f3n",
                factura.getImporteTotal(),
                factura.getDetalles().size()
        );
    }
}
