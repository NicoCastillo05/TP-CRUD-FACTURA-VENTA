package com.tp.apirest.dto;

import com.tp.apirest.modelo.Rol;
import jakarta.validation.constraints.*;

public record UsuarioParcial(String nombre, String apellido,
    @Email String mail, String celular, @Size(min = 6) String contrasena, Rol rol) {}
