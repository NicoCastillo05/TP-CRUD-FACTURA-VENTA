package com.tp.apirest.controlador;

import com.tp.apirest.dto.FacturaReporteDTO;
import com.tp.apirest.dto.FacturaRequestDTO;
import com.tp.apirest.servicio.FacturaReporteServicio;
import com.tp.apirest.servicio.FacturaService;
import jakarta.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.net.URI;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/api/facturas")
public class FacturaControlador {
    private final FacturaReporteServicio servicio;
    private final FacturaService servicioFactura;

    public FacturaControlador(FacturaReporteServicio servicio, FacturaService servicioFactura) {
        this.servicio = servicio;
        this.servicioFactura = servicioFactura;
    }

    @GetMapping
    public List<FacturaReporteDTO> listar(
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date fechaDesde,
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date fechaHasta,
            @RequestParam(required = false) String estado,
            @RequestParam(required = false) Double montoMinimo) {
        return servicio.buscar(fechaDesde, fechaHasta, estado, montoMinimo);
    }

    @PostMapping
    public ResponseEntity<FacturaReporteDTO> crear(@Valid @RequestBody FacturaRequestDTO entrada) {
        FacturaReporteDTO resultado = servicioFactura.crear(entrada);
        return ResponseEntity.created(URI.create("/api/facturas/" + resultado.numeroFactura())).body(resultado);
    }

    @PutMapping("/{id}")
    public FacturaReporteDTO actualizar(@PathVariable Long id, @Valid @RequestBody FacturaRequestDTO entrada) {
        return servicioFactura.actualizar(id, entrada);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        servicioFactura.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
