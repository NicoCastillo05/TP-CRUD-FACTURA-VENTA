package com.tp.apirest.modelo;

public enum Estado { PENDIENTE, CONFIRMADO, TERMINADO, CANCELADO }
