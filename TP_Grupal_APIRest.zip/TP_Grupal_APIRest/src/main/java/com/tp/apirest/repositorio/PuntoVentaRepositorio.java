package com.tp.apirest.repositorio;

import com.tp.PuntoVenta;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PuntoVentaRepositorio extends JpaRepository<PuntoVenta, Long> {
}
