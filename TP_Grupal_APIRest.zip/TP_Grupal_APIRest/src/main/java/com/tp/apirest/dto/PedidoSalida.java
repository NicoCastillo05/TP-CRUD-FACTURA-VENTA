package com.tp.apirest.dto;

import com.tp.apirest.modelo.Estado;
import com.tp.apirest.modelo.FormaPago;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public record PedidoSalida(Long id, LocalDate fecha, Estado estado, Double total,
    FormaPago formaPago, Long usuarioId, String usuarioNombre,
    List<DetalleSalida> detalles, LocalDateTime createdAt) {}
