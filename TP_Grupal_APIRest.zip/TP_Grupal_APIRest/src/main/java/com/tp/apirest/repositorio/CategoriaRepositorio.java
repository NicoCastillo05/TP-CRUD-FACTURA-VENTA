package com.tp.apirest.repositorio;

import com.tp.apirest.modelo.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.EntityGraph;
import java.util.Optional;
import java.util.List;

public interface CategoriaRepositorio extends JpaRepository<Categoria, Long> {
    Optional<Categoria> findByIdAndEliminadoFalse(Long id);
    List<Categoria> findAllByEliminadoFalse();
}
