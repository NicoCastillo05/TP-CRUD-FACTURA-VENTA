package com.tp.apirest.servicio;

import com.tp.apirest.dto.*;
import com.tp.apirest.excepcion.*;
import com.tp.apirest.modelo.Categoria;
import com.tp.apirest.repositorio.CategoriaRepositorio;
import com.tp.apirest.repositorio.ProductoRepositorio;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class CategoriaServicio {
    private final CategoriaRepositorio categorias;
    private final ProductoRepositorio productos;

    public CategoriaServicio(CategoriaRepositorio categorias, ProductoRepositorio productos) {
        this.categorias = categorias;
        this.productos = productos;
    }

    @Transactional(readOnly = true)
    public List<CategoriaSalida> listar() {
        return categorias.findAllByEliminadoFalse().stream().map(this::salida).toList();
    }

    @Transactional(readOnly = true)
    public CategoriaSalida buscar(Long id) { return salida(obtener(id)); }

    @Transactional
    public CategoriaSalida crear(CategoriaEntrada entrada) {
        Categoria c = new Categoria();
        c.setNombre(entrada.nombre().trim());
        c.setDescripcion(entrada.descripcion().trim());
        return salida(categorias.save(c));
    }

    @Transactional
    public CategoriaSalida actualizar(Long id, CategoriaEntrada entrada) {
        Categoria c = obtener(id);
        c.setNombre(entrada.nombre().trim());
        c.setDescripcion(entrada.descripcion().trim());
        return salida(c);
    }

    @Transactional
    public CategoriaSalida modificarParcial(Long id, CategoriaParcial entrada) {
        Categoria c = obtener(id);
        if (entrada.nombre() != null) c.setNombre(noVacio(entrada.nombre(), "nombre"));
        if (entrada.descripcion() != null) c.setDescripcion(noVacio(entrada.descripcion(), "descripcion"));
        return salida(c);
    }

    @Transactional
    public void eliminar(Long id) {
        Categoria c = obtener(id);
        if (productos.existsByCategoriaIdAndEliminadoFalse(id))
            throw new RecursoDuplicado("No se puede eliminar una categoría con productos activos");
        c.setEliminado(true);
    }

    public Categoria obtener(Long id) {
        return categorias.findByIdAndEliminadoFalse(id)
                .orElseThrow(() -> new RecursoNoEncontrado("Categoría no encontrada: " + id));
    }

    private String noVacio(String valor, String campo) {
        if (valor.isBlank()) throw new SolicitudInvalida("El campo " + campo + " no puede estar vacío");
        return valor.trim();
    }

    private CategoriaSalida salida(Categoria c) {
        return new CategoriaSalida(c.getId(), c.getNombre(), c.getDescripcion(), c.getCreatedAt());
    }
}
