package com.tp.apirest.modelo;

public enum FormaPago { TARJETA, TRANSFERENCIA, EFECTIVO }
