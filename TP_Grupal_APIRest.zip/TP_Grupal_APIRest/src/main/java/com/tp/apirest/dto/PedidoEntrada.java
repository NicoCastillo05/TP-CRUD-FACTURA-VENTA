package com.tp.apirest.dto;

import com.tp.apirest.modelo.FormaPago;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.time.LocalDate;
import java.util.List;

public record PedidoEntrada(@NotNull Long usuarioId, LocalDate fecha,
    @NotNull FormaPago formaPago,
    @NotEmpty List<@Valid DetalleEntrada> detalles) {}
