package com.tp.apirest.controlador;

import com.tp.apirest.dto.*;
import com.tp.apirest.servicio.CategoriaServicio;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/categorias")
public class CategoriaControlador {
    private final CategoriaServicio servicio;
    public CategoriaControlador(CategoriaServicio servicio) { this.servicio = servicio; }

    @GetMapping
    public List<CategoriaSalida> listar() { return servicio.listar(); }

    @GetMapping("/{id}")
    public CategoriaSalida buscar(@PathVariable Long id) { return servicio.buscar(id); }

    @PostMapping
    public ResponseEntity<CategoriaSalida> crear(@Valid @RequestBody CategoriaEntrada entrada) {
        CategoriaSalida creado = servicio.crear(entrada);
        return ResponseEntity.created(URI.create("/api/categorias/" + creado.id())).body(creado);
    }

    @PutMapping("/{id}")
    public CategoriaSalida actualizar(@PathVariable Long id, @Valid @RequestBody CategoriaEntrada entrada) {
        return servicio.actualizar(id, entrada);
    }

    @PatchMapping("/{id}")
    public CategoriaSalida modificar(@PathVariable Long id, @RequestBody CategoriaParcial entrada) {
        return servicio.modificarParcial(id, entrada);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        servicio.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
