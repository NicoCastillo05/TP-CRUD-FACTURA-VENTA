package com.tp.apirest.dto;

import jakarta.validation.constraints.*;

public record CategoriaEntrada(@NotBlank String nombre, @NotBlank String descripcion) {}
