package com.tp.apirest.repositorio;

import com.tp.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.EntityGraph;
import java.util.Optional;
import java.util.List;

public interface UsuarioRepositorio extends JpaRepository<Usuario, Long> {
    Optional<Usuario> findByIdAndEliminadoFalse(Long id);
    Optional<Usuario> findByMailIgnoreCaseAndEliminadoFalse(String mail);
    boolean existsByMailIgnoreCaseAndEliminadoFalse(String mail);
    List<Usuario> findAllByEliminadoFalse();
    Optional<Usuario> findByMailIgnoreCase(String mail);
}
