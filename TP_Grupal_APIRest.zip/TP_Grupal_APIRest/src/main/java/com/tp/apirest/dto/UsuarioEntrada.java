package com.tp.apirest.dto;

import com.tp.apirest.modelo.Rol;
import jakarta.validation.constraints.*;

public record UsuarioEntrada(@NotBlank String nombre, @NotBlank String apellido,
    @Email @NotBlank String mail, String celular,
    @NotBlank @Size(min = 6) String contrasena, @NotNull Rol rol) {}
