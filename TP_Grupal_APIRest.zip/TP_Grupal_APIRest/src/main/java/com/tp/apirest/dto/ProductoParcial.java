package com.tp.apirest.dto;

import jakarta.validation.constraints.*;

public record ProductoParcial(String nombre, @DecimalMin("0.01") Double precio,
    String descripcion, @Min(0) Integer stock, String imagen,
    Boolean disponible, Long categoriaId) {}
