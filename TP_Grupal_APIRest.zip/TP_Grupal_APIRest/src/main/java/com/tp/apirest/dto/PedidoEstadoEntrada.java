package com.tp.apirest.dto;

import com.tp.apirest.modelo.Estado;
import jakarta.validation.constraints.NotNull;

public record PedidoEstadoEntrada(@NotNull Estado estado) {}
