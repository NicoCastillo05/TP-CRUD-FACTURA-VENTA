package com.tp.apirest.repositorio;

import com.tp.CondicionIva;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CondicionIvaRepositorio extends JpaRepository<CondicionIva, Long> {
}
