package com.tp.apirest.repositorio;

import com.tp.apirest.modelo.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.EntityGraph;
import java.util.Optional;
import java.util.List;

public interface ProductoRepositorio extends JpaRepository<Producto, Long> {
    Optional<Producto> findByIdAndEliminadoFalse(Long id);
    List<Producto> findAllByEliminadoFalse();
    boolean existsByCategoriaIdAndEliminadoFalse(Long id);
}
