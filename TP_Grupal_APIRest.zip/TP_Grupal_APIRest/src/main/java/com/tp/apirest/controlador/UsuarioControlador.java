package com.tp.apirest.controlador;

import com.tp.apirest.dto.*;
import com.tp.apirest.servicio.UsuarioServicio;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/usuarios")
public class UsuarioControlador {
    private final UsuarioServicio servicio;
    public UsuarioControlador(UsuarioServicio servicio) { this.servicio = servicio; }

    @GetMapping
    public List<UsuarioSalida> listar() { return servicio.listar(); }

    @GetMapping("/{id}")
    public UsuarioSalida buscar(@PathVariable Long id) { return servicio.buscar(id); }

    @GetMapping("/buscar")
    public UsuarioSalida buscarPorMail(@RequestParam String mail) { return servicio.buscarPorMail(mail); }

    @PostMapping
    public ResponseEntity<UsuarioSalida> crear(@Valid @RequestBody UsuarioEntrada entrada) {
        UsuarioSalida creado = servicio.crear(entrada);
        return ResponseEntity.created(URI.create("/api/usuarios/" + creado.id())).body(creado);
    }

    @PutMapping("/{id}")
    public UsuarioSalida actualizar(@PathVariable Long id, @Valid @RequestBody UsuarioCambio entrada) {
        return servicio.actualizar(id, entrada);
    }

    @PatchMapping("/{id}")
    public UsuarioSalida modificar(@PathVariable Long id, @Valid @RequestBody UsuarioParcial entrada) {
        return servicio.modificarParcial(id, entrada);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        servicio.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
