package com.tp.apirest.dto;

public record DetalleSalida(Long id, Long productoId, String productoNombre,
    int cantidad, Double precioUnitario, Double subtotal) {}
