package com.tp.apirest;

import com.tp.apirest.modelo.Pedido;
import com.tp.apirest.modelo.Producto;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ModeloPedidoTest {
    @Test
    void sumaLosSubtotalesDeUnPedido() {
        Producto mouse = new Producto();
        mouse.setPrecio(1500.0);
        Producto teclado = new Producto();
        teclado.setPrecio(3000.0);
        Pedido pedido = new Pedido();
        pedido.addDetallePedido(2, mouse);
        pedido.addDetallePedido(1, teclado);
        assertEquals(6000.0, pedido.getTotal(), 0.001);
        assertEquals(2, pedido.getDetalles().size());
        pedido.deleteDetallePedidoByProducto(mouse);
        assertEquals(3000.0, pedido.getTotal(), 0.001);
    }
}
