package com.tp.apirest;


import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class ApiRestIntegracionTest {
    @Autowired MockMvc mvc;
    @Autowired ObjectMapper json;

    private JsonNode crear(String ruta, String cuerpo) throws Exception {
        MvcResult result = mvc.perform(post(ruta).contentType(MediaType.APPLICATION_JSON).content(cuerpo))
                .andExpect(status().isCreated()).andReturn();
        return json.readTree(result.getResponse().getContentAsString());
    }

    @Test
    void creaProductosYPedidosConDosDetalles() throws Exception {
        long categoria = crear("/api/categorias", """
                {"nombre":"Informática","descripcion":"Productos tecnológicos"}
                """).get("id").asLong();
        long usuario = crear("/api/usuarios", """
                {"nombre":"Ana","apellido":"Perez","mail":"ana.test@example.com",
                 "celular":"2610000000","contrasena":"prueba123","rol":"USUARIO"}
                """).get("id").asLong();
        long producto1 = crear("/api/productos", String.format("""
                {"nombre":"Mouse","precio":1500,"descripcion":"Mouse USB","stock":10,
                 "imagen":"mouse.png","disponible":true,"categoriaId":%d}
                """, categoria)).get("id").asLong();
        long producto2 = crear("/api/productos", String.format("""
                {"nombre":"Teclado","precio":3000,"descripcion":"Teclado USB","stock":8,
                 "imagen":"teclado.png","disponible":true,"categoriaId":%d}
                """, categoria)).get("id").asLong();

        JsonNode pedido = crear("/api/pedidos", String.format("""
                {"usuarioId":%d,"formaPago":"EFECTIVO","detalles":[
                    {"productoId":%d,"cantidad":2},
                    {"productoId":%d,"cantidad":1}]}
                """, usuario, producto1, producto2));
        assertEquals(6000.0, pedido.get("total").asDouble(), 0.001);
        assertEquals(2, pedido.get("detalles").size());

        mvc.perform(get("/api/productos/" + producto1))
                .andExpect(status().isOk()).andExpect(jsonPath("$.stock").value(8));

        mvc.perform(patch("/api/pedidos/" + pedido.get("id").asLong() + "/estado")
                        .contentType(MediaType.APPLICATION_JSON).content("""
                                {"estado":"CANCELADO"}
                                """))
                .andExpect(status().isOk()).andExpect(jsonPath("$.estado").value("CANCELADO"));
        mvc.perform(get("/api/productos/" + producto1))
                .andExpect(status().isOk()).andExpect(jsonPath("$.stock").value(10));
    }

    @Test
    void buscaUsuarioYActualizaCategoria() throws Exception {
        JsonNode usuario = crear("/api/usuarios", """
                {"nombre":"Luis","apellido":"Gomez","mail":"luis.test@example.com",
                 "celular":"2611111111","contrasena":"contraseña123","rol":"ADMIN"}
                """);
        mvc.perform(get("/api/usuarios/" + usuario.get("id").asLong()))
                .andExpect(status().isOk()).andExpect(jsonPath("$.mail").value("luis.test@example.com"))
                .andExpect(jsonPath("$.contrasena").doesNotExist());
        mvc.perform(get("/api/usuarios/buscar").param("mail", "luis.test@example.com"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.nombre").value("Luis"));

        long categoria = crear("/api/categorias", """
                {"nombre":"Ropa","descripcion":"Indumentaria"}
                """).get("id").asLong();
        mvc.perform(put("/api/categorias/" + categoria)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"nombre":"Ropa deportiva","descripcion":"Para entrenar"}
                                """))
                .andExpect(status().isOk()).andExpect(jsonPath("$.nombre").value("Ropa deportiva"));
    }

    @Test
    void validaErrores() throws Exception {
        mvc.perform(get("/api/usuarios/999999"))
                .andExpect(status().isNotFound()).andExpect(jsonPath("$.mensaje").exists());
        mvc.perform(post("/api/categorias").contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"nombre":"","descripcion":""}
                                """))
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.detalles.nombre").exists());
    }
    @Test
    void noPermiteMailDuplicadoNiPedidosSinStock() throws Exception {
        crear("/api/usuarios", """
                {"nombre":"Sofia","apellido":"Diaz","mail":"sofia@example.com",
                 "celular":"2612222222","contrasena":"clave123","rol":"USUARIO"}
                """);
        mvc.perform(post("/api/usuarios")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"nombre":"Otra","apellido":"Persona","mail":"sofia@example.com",
                                 "contrasena":"clave123","rol":"USUARIO"}
                                """))
                .andExpect(status().isConflict());

        long categoria = crear("/api/categorias", """
                {"nombre":"Libreria","descripcion":"Articulos de libreria"}
                """).get("id").asLong();
        long producto = crear("/api/productos", String.format("""
                {"nombre":"Carpeta","precio":800,"descripcion":"Carpeta A4","stock":1,
                 "disponible":true,"categoriaId":%d}
                """, categoria)).get("id").asLong();
        mvc.perform(post("/api/pedidos")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(String.format("""
                                {"usuarioId":1,"formaPago":"EFECTIVO", "detalles":[
                                    {"productoId":%d,"cantidad":2}]}
                                """, producto)))
                .andExpect(status().isBadRequest());
    }

}
