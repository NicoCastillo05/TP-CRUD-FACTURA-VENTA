package com.tp.apirest;

import com.tp.*;
import com.tp.apirest.modelo.*;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityManager;
import org.springframework.transaction.annotation.Transactional;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class ModeloAnteriorIntegradoTest {
    @Autowired EntityManagerFactory emf;
    @Autowired EntityManager em;

    @Test
    @Transactional
    void guardaEntidadesDelTrabajoAnteriorConUsuarioCompartido() {
        Usuario autor = new Usuario("autor", "clave", "Autor", "Test");
        autor.setMail("autor@ejemplo.com");
        em.persist(autor);
        Rubro rubro = new Rubro("Libreria", 1, autor);
        Marca marca = new Marca("Marca", 1, autor);
        Articulo articulo = new Articulo("L-1", "Carpeta", rubro, marca, autor);
        em.persist(articulo);
        em.flush();
        assertNotNull(articulo.getId());
        assertEquals(autor.getId(), articulo.getUsuarioCarga().getId());
        assertEquals("Marca", articulo.getMarca().getDenominacion());
    }

    @Test
    void registraLasEntidadesDelTrabajoAnteriorYElNuevo() {
        var entidades = emf.getMetamodel().getEntities().stream()
                .map(t -> t.getJavaType()).toList();
        assertTrue(entidades.contains(Articulo.class));
        assertTrue(entidades.contains(Cliente.class));
        assertTrue(entidades.contains(FacturaVenta.class));
        assertTrue(entidades.contains(FacturaVentaDetalle.class));
        assertTrue(entidades.contains(Usuario.class));
        assertTrue(entidades.contains(Pedido.class));
        assertTrue(entidades.contains(DetallePedido.class));
        assertTrue(entidades.contains(Producto.class));
        assertTrue(entidades.contains(Categoria.class));
        assertEquals(1, entidades.stream().filter(c -> c.getSimpleName().equals("Usuario")).count());
    }
}
