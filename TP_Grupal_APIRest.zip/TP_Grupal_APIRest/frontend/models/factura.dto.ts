/**
 * DTOs TypeScript que espejan los DTOs del backend Spring Boot.
 * Se usan para tipar las respuestas y peticiones de la API de facturación.
 */

/**
 * DTO de respuesta para el reporte/listado de facturas.
 * Espeja FacturaReporteDTO del backend.
 */
export interface FacturaReporteDTO {
    numeroFactura: string;
    fechaEmision: string;
    clienteDenominacion: string;
    condicionIva: string;
    puntoVentaDescripcion: string;
    importeTotal: number;
    cantidadItems: number;
}

/**
 * DTO de request para crear una factura.
 * Espeja FacturaRequestDTO del backend.
 */
export interface FacturaRequestDTO {
    clienteId: number;
    condicionIvaId: number;
    puntoVentaId: number;
    tipoMonedaId: number;
    fechaEmision: string;
    estado?: string;
    observaciones?: string;
    detalles: FacturaDetalleRequestDTO[];
}

/**
 * DTO de request para un detalle (renglón) de factura.
 * Espeja FacturaDetalleRequestDTO del backend.
 */
export interface FacturaDetalleRequestDTO {
    listaPrecioArticuloId: number;
    cantidad: number;
    precioUnitario: number;
    descripcion?: string;
    porcentajeBonificacion?: number;
}

/**
 * DTO de filtros para búsqueda de facturas.
 * Espeja FacturaFiltrosDTO del backend.
 */
export interface FacturaFiltrosDTO {
    fechaDesde?: string;
    fechaHasta?: string;
    estado?: string;
    montoMinimo?: number;
}
