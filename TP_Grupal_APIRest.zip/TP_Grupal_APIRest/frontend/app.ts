/**
 * app.ts
 * Punto de entrada del frontend de facturación.
 * Maneja la manipulación del DOM, el estado de ítems en memoria y la conexión
 * con FacturaService para todas las operaciones CRUD.
 */

import { FacturaService } from "./FacturaService";
import {
    FacturaFiltrosDTO,
    FacturaRequestDTO,
    FacturaDetalleRequestDTO,
    FacturaReporteDTO,
} from "./models/factura.dto";

// Instancia del servicio de facturas
const facturaService = new FacturaService();

// Estado en memoria: array de detalles (renglones) para la factura que se está dando de alta
let detalles: FacturaDetalleRequestDTO[] = [];

// ============================================================
// Referencias a elementos del DOM
// ============================================================

// Sección de búsqueda
const formBusqueda = document.getElementById("form-busqueda") as HTMLFormElement;
const btnLimpiarFiltros = document.getElementById(
    "btn-limpiar-filtros"
) as HTMLButtonElement;
const cuerpoTablaFacturas = document.getElementById(
    "cuerpo-tabla-facturas"
) as HTMLTableSectionElement;
const mensajeBusqueda = document.getElementById(
    "mensaje-busqueda"
) as HTMLDivElement;

// Sección de alta
const formAlta = document.getElementById("form-alta") as HTMLFormElement;
const btnAgregarDetalle = document.getElementById(
    "btn-agregar-detalle"
) as HTMLButtonElement;
const cuerpoTablaDetalles = document.getElementById(
    "cuerpo-tabla-detalles"
) as HTMLTableSectionElement;
const btnGuardarFactura = document.getElementById(
    "btn-guardar-factura"
) as HTMLButtonElement;
const btnLimpiarAlta = document.getElementById(
    "btn-limpiar-alta"
) as HTMLButtonElement;
const mensajeAlta = document.getElementById("mensaje-alta") as HTMLDivElement;

// Sección de listado
const cuerpoTablaListado = document.getElementById(
    "cuerpo-tabla-listado"
) as HTMLTableSectionElement;
const mensajeListado = document.getElementById(
    "mensaje-listado"
) as HTMLDivElement;

// ============================================================
// Utilidades
// ============================================================

/**
 * Muestra u oculta un mensaje de alerta en pantalla.
 */
function mostrarMensaje(
    elemento: HTMLDivElement,
    texto: string,
    tipo: "exito" | "error"
): void {
    elemento.textContent = texto;
    elemento.className = `mensaje ${tipo}`;
    elemento.style.display = "block";
    setTimeout(() => {
        elemento.style.display = "none";
    }, 5000);
}

/**
 * Formatea un número como moneda argentina.
 */
function formatearMonto(valor: number): string {
    return valor.toLocaleString("es-AR", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    });
}

// ============================================================
// Búsqueda de facturas
// ============================================================

/**
 * Obtiene facturas aplicando los filtros del formulario y renderiza ambas tablas.
 */
async function cargarFacturas(): Promise<void> {
    try {
        const filtros: FacturaFiltrosDTO = {
            fechaDesde: (
                document.getElementById("filtro-fecha-desde") as HTMLInputElement
            ).value || undefined,
            fechaHasta: (
                document.getElementById("filtro-fecha-hasta") as HTMLInputElement
            ).value || undefined,
            estado: (
                document.getElementById("filtro-estado") as HTMLSelectElement
            ).value || undefined,
            montoMinimo: (
                document.getElementById("filtro-monto-minimo") as HTMLInputElement
            ).value
                ? Number(
                      (
                          document.getElementById(
                              "filtro-monto-minimo"
                          ) as HTMLInputElement
                      ).value
                  )
                : undefined,
        };

        const facturas = await facturaService.obtenerFacturas(filtros);
        renderizarTablaFacturas(facturas, cuerpoTablaFacturas);
        renderizarTablaFacturas(facturas, cuerpoTablaListado);
    } catch (error: any) {
        mostrarMensaje(mensajeBusqueda, error.message, "error");
        mostrarMensaje(mensajeListado, error.message, "error");
    }
}

/**
 * Renderiza una lista de facturas en el cuerpo de tabla dado.
 * Conecta los eventos de los botones "Anular" y "Eliminar".
 */
function renderizarTablaFacturas(
    facturas: FacturaReporteDTO[],
    cuerpo: HTMLTableSectionElement
): void {
    cuerpo.innerHTML = "";

    if (facturas.length === 0) {
        const fila = document.createElement("tr");
        const celda = document.createElement("td");
        celda.colSpan = 8;
        celda.textContent = "No se encontraron facturas.";
        celda.style.textAlign = "center";
        fila.appendChild(celda);
        cuerpo.appendChild(fila);
        return;
    }

    for (const f of facturas) {
        const fila = document.createElement("tr");
        fila.innerHTML = `
            <td>${f.numeroFactura}</td>
            <td>${f.fechaEmision}</td>
            <td>${f.clienteDenominacion}</td>
            <td>${f.condicionIva}</td>
            <td>${f.puntoVentaDescripcion}</td>
            <td>${formatearMonto(f.importeTotal)}</td>
            <td>${f.cantidadItems}</td>
            <td class="actions">
                <button class="warning btn-anular" data-numero="${f.numeroFactura}">Anular</button>
                <button class="danger btn-eliminar" data-numero="${f.numeroFactura}">Eliminar</button>
            </td>
        `;
        cuerpo.appendChild(fila);
    }

    // Eventos: Anular (PUT estado)
    cuerpo.querySelectorAll(".btn-anular").forEach((btn) => {
        btn.addEventListener("click", async (e) => {
            const target = e.target as HTMLButtonElement;
            const numero = target.dataset.numero!;
            if (!confirm(`¿Anular factura ${numero}?`)) return;
            try {
                await facturaService.actualizarEstado(Number(numero), "ANULADA");
                mostrarMensaje(
                    mensajeBusqueda,
                    `Factura ${numero} anulada correctamente`,
                    "exito"
                );
                await cargarFacturas();
            } catch (error: any) {
                mostrarMensaje(mensajeBusqueda, error.message, "error");
            }
        });
    });

    // Eventos: Eliminar (DELETE)
    cuerpo.querySelectorAll(".btn-eliminar").forEach((btn) => {
        btn.addEventListener("click", async (e) => {
            const target = e.target as HTMLButtonElement;
            const numero = target.dataset.numero!;
            if (!confirm(`¿Eliminar factura ${numero}?`)) return;
            try {
                await facturaService.eliminarFactura(Number(numero));
                mostrarMensaje(
                    mensajeListado,
                    `Factura ${numero} eliminada correctamente`,
                    "exito"
                );
                await cargarFacturas();
            } catch (error: any) {
                mostrarMensaje(mensajeListado, error.message, "error");
            }
        });
    });
}

formBusqueda.addEventListener("submit", async (e) => {
    e.preventDefault();
    await cargarFacturas();
});

btnLimpiarFiltros.addEventListener("click", () => {
    formBusqueda.reset();
    cargarFacturas();
});

// ============================================================
// Alta de factura con detalles dinámicos
// ============================================================

/**
 * Renderiza la tabla de detalles en memoria y conecta sus eventos.
 */
function renderizarDetalles(): void {
    cuerpoTablaDetalles.innerHTML = "";

    for (let i = 0; i < detalles.length; i++) {
        const d = detalles[i];
        const fila = document.createElement("tr");
        fila.innerHTML = `
            <td><input type="number" value="${d.listaPrecioArticuloId}" min="1" data-field="listaPrecioArticuloId" data-index="${i}"></td>
            <td><input type="number" value="${d.cantidad}" min="1" step="1" data-field="cantidad" data-index="${i}"></td>
            <td><input type="number" value="${d.precioUnitario}" min="0" step="0.01" data-field="precioUnitario" data-index="${i}"></td>
            <td><input type="text" value="${d.descripcion || ""}" data-field="descripcion" data-index="${i}"></td>
            <td><input type="number" value="${d.porcentajeBonificacion ?? 0}" min="0" max="100" step="0.01" data-field="porcentajeBonificacion" data-index="${i}"></td>
            <td class="row-actions"><button class="danger btn-quitar-detalle" data-index="${i}">Quitar</button></td>
        `;
        cuerpoTablaDetalles.appendChild(fila);
    }

    // Actualizar el estado en memoria ante cambios en los inputs
    cuerpoTablaDetalles.querySelectorAll("input").forEach((input) => {
        input.addEventListener("change", (e) => {
            const target = e.target as HTMLInputElement;
            const index = Number(target.dataset.index!);
            const field = target.dataset.field!;
            const value = target.type === "number" ? Number(target.value) : target.value;

            if (field === "porcentajeBonificacion" && value === 0) {
                (detalles[index] as any)[field] = undefined;
            } else {
                (detalles[index] as any)[field] = value;
            }
        });
    });

    // Botón quitar renglón
    cuerpoTablaDetalles.querySelectorAll(".btn-quitar-detalle").forEach((btn) => {
        btn.addEventListener("click", (e) => {
            const target = e.target as HTMLButtonElement;
            const index = Number(target.dataset.index!);
            detalles.splice(index, 1);
            renderizarDetalles();
        });
    });
}

btnAgregarDetalle.addEventListener("click", () => {
    const nuevoDetalle: FacturaDetalleRequestDTO = {
        listaPrecioArticuloId: 0,
        cantidad: 1,
        precioUnitario: 0,
        descripcion: "",
        porcentajeBonificacion: undefined,
    };
    detalles.push(nuevoDetalle);
    renderizarDetalles();
});

btnGuardarFactura.addEventListener("click", async () => {
    if (detalles.length === 0) {
        mostrarMensaje(
            mensajeAlta,
            "Debe agregar al menos un detalle.",
            "error"
        );
        return;
    }

    const fechaEmision = (
        document.getElementById("alta-fecha-emision") as HTMLInputElement
    ).value;
    if (!fechaEmision) {
        mostrarMensaje(
            mensajeAlta,
            "La fecha de emisión es obligatoria.",
            "error"
        );
        return;
    }

    const factura: FacturaRequestDTO = {
        clienteId: Number(
            (document.getElementById("alta-cliente-id") as HTMLInputElement).value
        ),
        condicionIvaId: Number(
            (document.getElementById("alta-condicion-iva-id") as HTMLInputElement)
                .value
        ),
        puntoVentaId: Number(
            (document.getElementById("alta-punto-venta-id") as HTMLInputElement)
                .value
        ),
        tipoMonedaId: Number(
            (document.getElementById("alta-tipo-moneda-id") as HTMLInputElement)
                .value
        ),
        fechaEmision,
        estado:
            (document.getElementById("alta-estado") as HTMLInputElement).value ||
            undefined,
        observaciones:
            (document.getElementById("alta-observaciones") as HTMLTextAreaElement)
                .value || undefined,
        detalles,
    };

    try {
        const creada = await facturaService.crearFactura(factura);
        mostrarMensaje(
            mensajeAlta,
            `Factura ${creada.numeroFactura} creada correctamente`,
            "exito"
        );
        formAlta.reset();
        detalles = [];
        renderizarDetalles();
        await cargarFacturas();
    } catch (error: any) {
        mostrarMensaje(mensajeAlta, error.message, "error");
    }
});

btnLimpiarAlta.addEventListener("click", () => {
    formAlta.reset();
    detalles = [];
    renderizarDetalles();
    mensajeAlta.style.display = "none";
});

// ============================================================
// Inicialización
// ============================================================

cargarFacturas();
