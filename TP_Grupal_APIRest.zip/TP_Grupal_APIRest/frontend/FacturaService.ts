import { FacturaReporteDTO, FacturaRequestDTO, FacturaFiltrosDTO } from "./models/factura.dto";

/**
 * Servicio para consumir la API REST de facturación.
 * Base URL: http://localhost:8080/api/facturas
 * Usa fetch nativo con async/await para todas las llamadas HTTP.
 */
export class FacturaService {
    private readonly baseUrl = "http://localhost:8080/api/facturas";

    /**
     * Obtiene el listado de facturas aplicando filtros opcionales.
     * GET /api/facturas?fechaDesde=...&fechaHasta=...&estado=...&montoMinimo=...
     */
    async obtenerFacturas(filtros: FacturaFiltrosDTO): Promise<FacturaReporteDTO[]> {
        const params = new URLSearchParams();
        if (filtros.fechaDesde) params.append("fechaDesde", filtros.fechaDesde);
        if (filtros.fechaHasta) params.append("fechaHasta", filtros.fechaHasta);
        if (filtros.estado) params.append("estado", filtros.estado);
        if (filtros.montoMinimo !== undefined)
            params.append("montoMinimo", String(filtros.montoMinimo));

        const url = `${this.baseUrl}?${params.toString()}`;
        const response = await fetch(url, { method: "GET" });

        if (!response.ok) {
            const errorBody = await response.text().catch(() => "");
            throw new Error(
                `Error al obtener facturas (${response.status}): ${errorBody}`
            );
        }

        return await response.json();
    }

    /**
     * Crea una nueva factura con sus detalles.
     * POST /api/facturas con body JSON.
     */
    async crearFactura(factura: FacturaRequestDTO): Promise<FacturaReporteDTO> {
        const response = await fetch(this.baseUrl, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(factura),
        });

        if (!response.ok) {
            const errorBody = await response.text().catch(() => "");
            throw new Error(
                `Error al crear factura (${response.status}): ${errorBody}`
            );
        }

        return await response.json();
    }

    /**
     * Actualiza el estado de una factura existente (ej. anular).
     * PUT /api/facturas/{id} con body { estado, observaciones? }.
     */
    async actualizarEstado(
        id: number,
        estado: string,
        observaciones?: string
    ): Promise<FacturaReporteDTO> {
        const response = await fetch(`${this.baseUrl}/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ estado, observaciones }),
        });

        if (!response.ok) {
            const errorBody = await response.text().catch(() => "");
            throw new Error(
                `Error al actualizar estado (${response.status}): ${errorBody}`
            );
        }

        return await response.json();
    }

    /**
     * Elimina una factura por su ID.
     * DELETE /api/facturas/{id}.
     */
    async eliminarFactura(id: number): Promise<void> {
        const response = await fetch(`${this.baseUrl}/${id}`, {
            method: "DELETE",
        });

        if (!response.ok) {
            const errorBody = await response.text().catch(() => "");
            throw new Error(
                `Error al eliminar factura (${response.status}): ${errorBody}`
            );
        }
    }
}
