# TP API REST — Programación III (integrado)

Este es **un solo proyecto Maven/Spring Boot**, no dos TPs separados.
Parte del código de `TP_Grupal_Spring_Boot-main.zip` y suma lo pedido en «PROGRAMACIÓN III Api Rest».

## Qué quedó del trabajo anterior

En `src/main/java/com/tp/` se conservan las 17 clases Java del modelo JPA:
`Articulo`, `AuditoriaApp`, `Cliente`, `CondicionIva`, `Contacto`,
`Domicilio`, `EntityId`, `FacturaVenta`, `FacturaVentaDetalle`,
`ListaPrecio`, `ListaPrecioArticulo`, `Marca`, `PuntoVenta`, `Rubro`,
`TipoMoneda`, `Usuario` y `Main`.

`Usuario` **es la misma entidad** que usaban para auditar el modelo JPA.
Se añadieron `mail`, `celular`, `rol`, el borrado lógico, la fecha de creación
heredada y la asociación con pedidos; se mantuvieron `usuario`, `clave`, `nombre`,
`apellido` y el resto de relaciones antiguas. `contrasena` en la API se guarda
en el campo preexistente `clave` (mediante hash BCrypt).
`Main` ahora inicia Spring Boot; la demostración anterior de JPA se dejó en
`documentacion/Main-JPA-anterior.java.txt` como referencia, junto con el antiguo
`persistence.xml` (que ya no se usa para no crear dos configuraciones JPA).

## Qué agrega el trabajo API REST

En `src/main/java/com/tp/apirest/` están `Pedido`, `DetallePedido`,
`Producto`, `Categoria`, las enumeraciones, la interfaz `Calculable`,
los DTOs, Repository, Service, Controller y AdviceController.
Además, `/api/facturas` reutiliza las **facturas del trabajo anterior**
y ofrece la proyección `FacturaReporteDTO` con los filtros opcionales
`fechaDesde`, `fechaHasta`, `estado` y `montoMinimo` (según la consigna
de servicios REST incluida en el repositorio anterior).
Se implementan GET/POST/PUT/PATCH/DELETE, validaciones,
control de stock, borrado lógico, búsqueda de usuarios por id y mail
(con salida por consola), y Swagger.

## Abrir y ejecutar

1. Descomprimir y abrir esta **carpeta principal** como proyecto Maven en IntelliJ IDEA o VS Code.
2. Tener instalado **Java 21** y Maven (o usar Maven integrado en IntelliJ).
3. Ejecutar `mvn clean test` para revisar las pruebas automatizadas.
4. Ejecutar `mvn spring-boot:run` desde la carpeta que contiene `pom.xml`.
5. Abrir http://localhost:8080/swagger-ui.html .
6. En Postman: Import > seleccionar `postman/TP_APIRest.postman_collection.json`.
   Ejecutar las solicitudes en el orden numerado; guardan los IDs automáticamente.

Los datos se guardan en H2 en `datos/` (carpeta creada automáticamente).
No hace falta instalar PostgreSQL para usar esta versión.
**No incluir `target/`, `datos/*.db` ni archivos binarios al entregar.**

## Comprobación de consignas

- Dos usuarios: Postman.
- Tres categorías: Postman.
- Diez productos: Postman.
- Tres pedidos con dos detalles o más cada uno: Postman.
- Actualizar categoría: `PUT /api/categorias/{id}`.
- Buscar usuario por ID: `GET /api/usuarios/{id}`; aparece en consola.
- Buscar usuario por correo: `GET /api/usuarios/buscar?mail=...`; aparece en consola.
- Swagger: http://localhost:8080/swagger-ui.html .
- Test de integración del modelo anterior: `ModeloAnteriorIntegradoTest`.

**Nota sobre pruebas:** el proyecto necesita descargar las dependencias Maven en
una computadora con Internet. En el entorno donde se generó el ZIP no es posible
ejecutar Maven/Spring Boot y por eso el inicio real debe verificarse localmente.
